This was a very simple preview ROM made for Cool Herders on the GBA, consisting mostly of just a promotional slideshow with some of the original music playing through GSM compression.
